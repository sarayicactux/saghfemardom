-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2019 at 08:19 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saghf`
--

-- --------------------------------------------------------

--
-- Table structure for table `advs`
--

CREATE TABLE `advs` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `admin_id` int(10) NOT NULL DEFAULT '0',
  `pro_id` int(5) NOT NULL,
  `pro_name` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `city_id` int(11) NOT NULL,
  `city_name` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `business_type` int(2) NOT NULL,
  `business_gr` int(5) NOT NULL,
  `bgRN` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `video_url` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `checked` int(1) NOT NULL DEFAULT '0',
  `reason` text COLLATE utf8mb4_persian_ci,
  `visitcnt` int(10) NOT NULL DEFAULT '0',
  `dis_status` int(1) NOT NULL DEFAULT '1',
  `actived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `advs`
--

INSERT INTO `advs` (`id`, `user_id`, `admin_id`, `pro_id`, `pro_name`, `city_id`, `city_name`, `title`, `description`, `business_type`, `business_gr`, `bgRN`, `video_url`, `status`, `checked`, `reason`, `visitcnt`, `dis_status`, `actived_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 6, 'بوشهر', 262, 'برازجان', 'صدای احسان خواجه امیری sdfsd sdfsdfs df', 'صدای احسان خواجه امیری صدای احسان خواجه امیری صدای احسان خواجه امیری صدای احسان خواجه امیری adasd adas', 1, 1, NULL, 'panel/bAdv/310060t_video5915781773328909548.mp4', 0, 0, '', 0, 0, NULL, '2019-06-22 13:53:46', '2019-06-30 08:24:20'),
(2, 1, 1, 17, 'قزوین', 703, 'آبگرم', 'صدای احسان خواجه امیری 2 شششش', 'لطفا توضیحات آگاهی را وارد کنید\n لطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\nلطفا توضیحات آگاهی را وارد کنید\n', 2, 2, NULL, 'panel/bAdv/110832t_video5900263790200489452.mp4', 0, 0, 'یبل یبل ثق لیببیلیبلیبلثقف یبیبل یبلیبل یبل', 0, 1, '2019-06-08 08:30:31', '2019-06-23 12:30:42', '2019-06-30 12:37:02'),
(3, 2, 0, 7, 'تهران', 306, 'تهران', 'qwewqwe qwe', 'qweqwe qweqw eqwe sdfs sd sdf sdfs fsd sdf sdf sdfsd', 2, 2, NULL, '', 1, 1, NULL, 0, 1, '2019-06-30 12:47:12', '2019-06-22 12:17:15', '2019-06-30 12:47:12'),
(4, 3, 0, 28, 'مركزي', 1032, 'اراک', 'sdfsdf sdf sdfs dfsdf', 'سیل سیبلبابیل یثقف ثقفیبلبللثقف', 3, 6, NULL, 'panel/bAdv/1850335J3BrjEJ.mp4', 1, 1, 'فاغ قغقفقفقفقف  قغفق غق غق غقف قف غق قفغ', 0, 1, '2019-06-30 13:08:01', '2019-06-24 06:39:10', '2019-06-30 13:08:01'),
(5, 4, 0, 7, 'تهران', 306, 'تهران', 'asdasd asdasdasdasdas', 'asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas asdasdasdasdas ', 1, 7, '', '', 1, 1, NULL, 0, 1, '2019-07-08 08:42:51', '2019-07-08 08:41:23', '2019-07-08 08:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `adv_image`
--

CREATE TABLE `adv_image` (
  `id` int(10) NOT NULL,
  `adv_id` int(10) NOT NULL,
  `img_url` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `adv_image`
--

INSERT INTO `adv_image` (`id`, `adv_id`, `img_url`, `created_at`, `updated_at`) VALUES
(1, 1, 'panel/bAdv/53387792dfb559-a598-4118-9040-a24869327353.jpg', '2019-06-08 08:28:25', '2019-06-08 08:28:25'),
(2, 1, 'panel/bAdv/73653652551d4d-fcce-40ea-b7fb-a4ba97c7e8ec.jpg', '2019-06-08 08:28:25', '2019-06-08 08:28:25'),
(3, 1, 'panel/bAdv/64896914.jpg', '2019-06-08 08:28:25', '2019-06-08 08:28:25'),
(4, 1, 'panel/bAdv/92826index.jpg', '2019-06-08 08:30:31', '2019-06-08 08:30:31'),
(5, 1, 'panel/bAdv/321885i44ndex.jpg', '2019-06-08 08:30:31', '2019-06-08 08:30:31'),
(7, 3, 'panel/bAdv/30917392dfb559-a598-4118-9040-a24869327353.jpg', '2019-06-22 12:17:15', '2019-06-22 12:17:15'),
(8, 3, 'panel/bAdv/49977214.jpg', '2019-06-22 12:17:15', '2019-06-22 12:17:15'),
(9, 3, 'panel/bAdv/278299dccd067e-63c1-44a3-93e2-584e29981644.jpg', '2019-06-22 12:17:15', '2019-06-22 12:17:15'),
(55, 2, 'panel/bAdv/339385ef1.jpg', '2019-06-23 12:30:42', '2019-06-23 12:30:43'),
(56, 2, 'panel/bAdv/161368nek1.jpg', '2019-06-23 12:30:42', '2019-06-23 12:30:43'),
(57, 2, 'panel/bAdv/696717ef2.jpg', '2019-06-23 12:30:42', '2019-06-23 12:30:43'),
(58, 2, 'panel/bAdv/648712ef8.jpg', '2019-06-23 12:30:42', '2019-06-23 12:30:43'),
(59, 2, 'panel/bAdv/281427ef3.png', '2019-06-23 12:30:42', '2019-06-23 12:30:43'),
(60, 4, 'panel/bAdv/232864creating-a-safe-welding-environment-0.jpg', '2019-06-24 06:39:10', '2019-06-24 06:39:10'),
(61, 4, 'panel/bAdv/566501images.jpg', '2019-06-24 06:39:10', '2019-06-24 06:39:10'),
(62, 4, 'panel/bAdv/918425welder.jpg', '2019-06-24 06:39:10', '2019-06-24 06:39:10'),
(63, 5, 'panel/bAdv/90674120180302_181802.jpg', '2019-07-08 08:41:23', '2019-07-08 08:41:23'),
(64, 5, 'panel/bAdv/927739445507072_39092.jpg', '2019-07-08 08:41:23', '2019-07-08 08:41:23'),
(65, 5, 'panel/bAdv/474465445509847_145868.jpg', '2019-07-08 08:41:23', '2019-07-08 08:41:23'),
(66, 5, 'panel/bAdv/629697saipa (1).jpg', '2019-07-08 08:41:23', '2019-07-08 08:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `en_title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `logo` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `title`, `en_title`, `slug`, `logo`, `created_at`, `updated_at`) VALUES
(1, 'هیوندایی', 'hyundai', 'هیوندایی', 'panel/register/91256Hyundai-logo-silver-2560x1440.png', '2019-05-11 09:13:38', '2019-05-11 09:13:38'),
(2, 'تویوتا', 'toyota', 'تویوتا', 'panel/register/28270Toyota-logo-1989-2560x1440.png', '2019-05-11 09:14:53', '2019-05-11 09:19:50'),
(3, 'کیا', 'kia', 'کیا', 'panel/register/360994KIA_logo2.svg.png', '2019-05-11 09:16:56', '2019-05-11 09:16:56'),
(4, 'پژو', 'pegout', 'پژو', 'panel/register/894650i44ndex.jpg', '2019-06-08 08:44:24', '2019-06-08 08:44:24'),
(5, 'رنو', 'renuat', 'رنو', 'panel/register/331278سشدیقخ.jpg', '2019-06-24 06:27:37', '2019-06-24 06:27:37'),
(6, 'ایران خودرو', 'ikco', 'ایران-خودرو', 'panel/register/7584221.jpg', '2019-06-24 06:29:38', '2019-06-24 06:29:38');

-- --------------------------------------------------------

--
-- Table structure for table `business_gr`
--

CREATE TABLE `business_gr` (
  `id` int(6) NOT NULL,
  `business_type_id` int(2) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `business_gr`
--

INSERT INTO `business_gr` (`id`, `business_type_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 'پخش لوازم لوکس خودرو', 'پخش لوازم لوکس خودرو', 'ثقصث', '2019-05-12 09:06:29', '2019-05-12 09:06:29'),
(2, 2, 'تولید کاشی سرامیکی', 'تولید کاشی سرامیکی', 'ثضصضصث', '2019-05-12 09:06:47', '2019-05-12 09:08:47'),
(3, 2, 'تولید  تجهیزات دامپروری', 'تولید  تجهیزات دامپروری', 'صثقصث', '2019-05-12 09:08:54', '2019-05-12 09:09:02'),
(4, 1, 'فروش لوازم خانگی', 'فروش-لوازم-خانگی', 'سبسیب سیب سبس س یبلبی لیب ل', '2019-06-24 06:34:08', '2019-06-24 06:34:08'),
(5, 2, 'ثق', 'ثق', 'ثقفف', '2019-06-24 06:34:25', '2019-06-24 06:34:25'),
(6, 3, 'تراشکاری', 'تراشکاری', 'تراشکاری', '2019-06-24 06:34:49', '2019-06-24 06:34:49'),
(7, 1, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2019-07-08 08:42:51', '2019-07-08 08:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `business_type`
--

CREATE TABLE `business_type` (
  `id` int(2) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `business_type`
--

INSERT INTO `business_type` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'کسب وکار', '', '2019-05-12 08:18:36', NULL),
(2, 'کارگاه های تولیدی', '', '2019-05-12 08:18:36', NULL),
(3, 'کارگاه های صنعتی', '', '2019-05-12 08:18:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(10) NOT NULL,
  `brand1_id` int(4) NOT NULL,
  `brand2_id` int(4) NOT NULL,
  `model` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `tech_spec` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `show_price` int(1) NOT NULL DEFAULT '0',
  `price` bigint(11) NOT NULL DEFAULT '0',
  `video` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `brand1_id`, `brand2_id`, `model`, `slug`, `tech_spec`, `description`, `show_price`, `price`, `video`, `created_at`, `updated_at`) VALUES
(1, 2, 3, 'defwe', 'defwe', '<p>sf</p>', '<p>werwer</p>', 0, 300, 'panel/register/8385755J3BrjEJ.mp4', '2019-05-12 07:28:45', '2019-05-12 07:56:54'),
(2, 1, 0, 'sonata', 'sonata', '<p>f</p>', '<p>sdf</p>', 1, 200000000, 'panel/register/448125t_video5900263790200489452.mp4', '2019-05-12 08:09:34', '2019-05-12 08:09:34'),
(3, 4, 4, '206', '206', '<p>sdfsd</p>', '<p>sfsd</p>', 1, 200000000, 'panel/register/422059t_video5900263790200489452.mp4', '2019-06-08 08:45:14', '2019-06-11 11:06:56'),
(4, 4, 4, '206SD', '206SD', '<p>sdfsdfsd sdfsfsdf</p>', '<p>sdfsdf d</p>', 1, 95000000, 'panel/register/231202RTYeQbui.mp4', '2019-06-11 11:06:39', '2019-06-11 11:06:39'),
(5, 5, 6, 'L90 E2', 'L90-E2', '<p>قلیب یبل یلیب</p>\n<p>ل یبل یب</p>\n<p>لیب</p>\n<p>ل یب</p>\n<p>لیب لی</p>\n<p>بلیل</p>', '<p>یبل بیلی بیبل یبلیبلیل&nbsp ثبل ی</p>', 1, 100000000, 'panel/register/6404545J3BrjEJ.mp4', '2019-06-24 06:32:17', '2019-06-24 06:32:17');

-- --------------------------------------------------------

--
-- Table structure for table `car_advs`
--

CREATE TABLE `car_advs` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `admin_id` int(10) NOT NULL,
  `pro_id` int(5) NOT NULL,
  `pro_name` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `city_id` int(5) NOT NULL,
  `city_name` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `selling_type` int(1) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `brand` int(5) NOT NULL,
  `model` int(10) NOT NULL,
  `video_url` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `price` int(11) NOT NULL DEFAULT '0',
  `loan_amount` int(11) NOT NULL DEFAULT '0',
  `pre_payment` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `payment_pr` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `payment_count` int(3) NOT NULL DEFAULT '0',
  `payment_amount` int(10) NOT NULL DEFAULT '0',
  `delivery_time` text COLLATE utf8mb4_persian_ci NOT NULL,
  `terms` text COLLATE utf8mb4_persian_ci,
  `status` int(1) NOT NULL DEFAULT '0',
  `checked` int(1) NOT NULL DEFAULT '0',
  `reason` text COLLATE utf8mb4_persian_ci,
  `visitcnt` int(10) NOT NULL DEFAULT '0',
  `dis_status` int(1) NOT NULL DEFAULT '1',
  `actived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `car_advs`
--

INSERT INTO `car_advs` (`id`, `user_id`, `admin_id`, `pro_id`, `pro_name`, `city_id`, `city_name`, `selling_type`, `title`, `description`, `brand`, `model`, `video_url`, `price`, `loan_amount`, `pre_payment`, `payment_pr`, `payment_count`, `payment_amount`, `delivery_time`, `terms`, `status`, `checked`, `reason`, `visitcnt`, `dis_status`, `actived_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 7, 'تهران', 306, 'تهران', 1, 'پژو 206 سفید', 'سیبسی سی بسیبسی لطفا توضیحات آگاهی را وارد کنید لطفا توضیحات آگاهی را وارد کنید\n سیب سیب لطفا توضیحات آگاهی را وارد کنید لطفا توضیحات آگاهی را وارد کنیدلطفا توضیحات آگاهی را وارد کنید لطفا توضیحات آگاهی را وارد کنید لطفا توضیحات آگاهی را وارد کنید لطفا توضیحات آگاهی را وارد کنید\nس یب', 4, 3, 'panel/bAdv/9214905J3BrjEJ.mp4', 85000000, 0, NULL, NULL, 0, 0, 'فوری', NULL, 0, 1, 'ظطزظطزظطز طزب سیسیبسی سیب سی ب سیب سیب  سیب سیبسی سیب سی ب سیب سی  سیب سیب', 0, 0, '2019-06-08 13:52:58', '2019-06-18 11:45:09', '2019-06-30 13:39:07'),
(2, 1, 1, 26, 'لرستان', 956, 'بروجرد', 1, '206 تیپ 5', 'سیبس سیبسیبسی شسی ش شسی شسی شس یسبسی', 4, 3, 'panel/bAdv/993043RTYeQbui.mp4', 85000000, 0, NULL, NULL, 0, 0, 'فوری', NULL, 1, 1, NULL, 0, 0, '2019-06-30 13:36:00', '2019-06-28 11:48:00', '2019-06-30 13:36:00'),
(3, 1, 0, 10, 'خراسان رضوي', 425, 'چناران', 2, 'Highcharts Demo', 'سی سیب سی سیبصثق سیب صث سیب سیبص سیب سیب4ب سب', 4, 3, 'panel/carAdv/569938RTYeQbui.mp4', 85000000, 40000000, '45000000', '4500000', 12, 0, 'فوری', NULL, 0, 1, 'به دسیب سیب سیلیل بی دلیلی', 0, 0, '2019-06-08 13:52:58', '2019-06-05 13:52:58', '2019-06-30 13:57:05'),
(4, 1, 0, 7, 'تهران', 306, 'تهران', 2, '206 صندوقدار تنوع رنگ', 'سیب \nسیب \n سیب\n سیب\n سیب\n سیب\n سیب\n', 4, 4, 'panel/carAdv/99689RTYeQbui.mp4', 98000000, 48000000, '45000000', 'سه ماه یکبار', 12, 50000000, '30 روزه', NULL, 1, 1, NULL, 0, 1, '2019-06-30 13:56:55', '2019-06-16 11:54:39', '2019-06-30 13:56:55'),
(5, 1, 0, 7, 'تهران', 308, 'چهارباغ', 2, 'سوناتا 2018', 'یسبس یب \nسیب سیب سیب سصثقصق یبس منصثا نتطزمرک ثغ سسمکصثع سیمکبثع ئدس کخیببصثع', 1, 2, 'panel/carAdv/8382295J3BrjEJ.mp4', 188000000, 88000000, '100000000', 'سه ماه یکبار', 12, 10000000, '30 روزه', NULL, 0, 1, 'سیب سیب سیبسیب سیبسیبسیب سیبسیسیب س', 0, 0, '2019-06-16 11:54:39', '2019-06-16 11:58:56', '2019-06-30 13:57:18'),
(6, 1, 0, 28, 'مركزي', 9999, 'همه شهرهای استان', 2, 'فروش اقساطی پراید 131 سفید', 'سیبسی سیب سیب سیبیسب سیب\nیسی بسیب س', 6, 5, 'panel/carAdv/251478t_video5900263790200489452.mp4', 45000000, 12000000, '33000000', 'ماهانه', 12, 1600000, '24 ساعته', NULL, 0, 0, NULL, 0, 1, '2019-06-16 11:54:39', '2019-06-24 08:01:20', '2019-06-30 08:16:24');

-- --------------------------------------------------------

--
-- Table structure for table `car_adv_image`
--

CREATE TABLE `car_adv_image` (
  `id` int(10) NOT NULL,
  `adv_id` int(10) NOT NULL,
  `img_url` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `car_adv_image`
--

INSERT INTO `car_adv_image` (`id`, `adv_id`, `img_url`, `created_at`, `updated_at`) VALUES
(4, 2, 'panel/bAdv/308968AX6O9tMy.jpg', '2019-06-08 11:48:00', '2019-06-08 11:48:00'),
(5, 2, 'panel/bAdv/854614AXxmoQ4q.jpg', '2019-06-08 11:48:00', '2019-06-08 11:48:00'),
(6, 3, 'panel/carAdv/598408AX6O9tMy.jpg', '2019-06-08 13:52:58', '2019-06-08 13:52:58'),
(7, 3, 'panel/carAdv/594132AXxmoQ4q.jpg', '2019-06-08 13:52:58', '2019-06-08 13:52:58'),
(8, 3, 'panel/carAdv/4868523.jpg', '2019-06-08 13:52:58', '2019-06-08 13:52:58'),
(9, 4, 'panel/carAdv/659076AX6O9tMy.jpg', '2019-06-16 11:54:39', '2019-06-16 11:54:39'),
(10, 4, 'panel/carAdv/7189242.jpg', '2019-06-16 11:54:39', '2019-06-16 11:54:39'),
(11, 4, 'panel/carAdv/6016443.jpg', '2019-06-16 11:54:39', '2019-06-16 11:54:39'),
(12, 4, 'panel/carAdv/8174211.jpg', '2019-06-16 11:54:39', '2019-06-16 11:54:39'),
(13, 4, 'panel/carAdv/3352132016-Hyundai-Sonata-0.jpg', '2019-06-16 11:54:39', '2019-06-16 11:54:39'),
(18, 1, 'panel/bAdv/15464notebook3.jpg', '2019-06-23 13:06:42', '2019-06-23 13:06:42'),
(19, 1, 'panel/carAdv/287697nek4.jpg', '2019-06-23 13:06:42', '2019-06-23 13:06:42'),
(20, 1, 'panel/bAdv/712803AX6O9tMy.jpg', '2019-06-23 13:06:42', '2019-06-23 13:06:42'),
(21, 1, 'panel/bAdv/808365AX6O9tMy.jpg', '2019-06-23 13:06:42', '2019-06-23 13:06:42'),
(26, 5, 'panel/carAdv/756599nek1.jpg', '2019-06-23 13:30:05', '2019-06-23 13:30:05'),
(27, 5, 'panel/carAdv/8217nek2.jpg', '2019-06-23 13:30:05', '2019-06-23 13:30:05'),
(28, 5, 'panel/carAdv/963349nek3.jpg', '2019-06-23 13:30:05', '2019-06-23 13:30:05'),
(29, 5, 'panel/carAdv/5923372016-Hyundai-Sonata-0.jpg', '2019-06-23 13:30:05', '2019-06-23 13:30:05'),
(30, 6, 'panel/carAdv/4156101.jpg', '2019-06-24 08:01:20', '2019-06-24 08:01:21'),
(31, 6, 'panel/carAdv/7409312.jpg', '2019-06-24 08:01:20', '2019-06-24 08:01:21'),
(32, 6, 'panel/carAdv/5938843.jpg', '2019-06-24 08:01:20', '2019-06-24 08:01:21');

-- --------------------------------------------------------

--
-- Table structure for table `car_images`
--

CREATE TABLE `car_images` (
  `id` int(10) NOT NULL,
  `car_id` int(10) NOT NULL,
  `img_url` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `car_images`
--

INSERT INTO `car_images` (`id`, `car_id`, `img_url`, `created_at`, `updated_at`) VALUES
(57, 1, 'panel/register/73437514.jpg', '2019-05-12 07:56:54', '2019-05-12 07:56:54'),
(58, 1, 'panel/register/14000dccd067e-63c1-44a3-93e2-584e29981644.jpg', '2019-05-12 07:56:54', '2019-05-12 07:56:54'),
(59, 1, 'panel/register/281625c2d56b2e-94d5-4230-b3da-126dcf021147.jpg', '2019-05-12 07:56:54', '2019-05-12 07:56:54'),
(60, 2, 'panel/register/1.jpg', '2019-05-12 08:09:34', '2019-05-12 08:09:34'),
(61, 2, 'panel/register/2.jpg', '2019-05-12 08:09:34', '2019-05-12 08:09:34'),
(62, 2, 'panel/register/3.jpg', '2019-05-12 08:09:34', '2019-05-12 08:09:34'),
(63, 2, 'panel/register/4.jpg', '2019-05-12 08:09:34', '2019-05-12 08:09:34'),
(66, 4, 'panel/register/913396AX6O9tMy.jpg', '2019-06-11 11:06:39', '2019-06-11 11:06:39'),
(67, 4, 'panel/register/175789AXxmoQ4q.jpg', '2019-06-11 11:06:39', '2019-06-11 11:06:39'),
(68, 4, 'panel/register/364785car1.jpg', '2019-06-11 11:06:39', '2019-06-11 11:06:39'),
(69, 4, 'panel/register/409556car2.jpg', '2019-06-11 11:06:39', '2019-06-11 11:06:39'),
(70, 3, 'panel/register/42817152551d4d-fcce-40ea-b7fb-a4ba97c7e8ec.jpg', '2019-06-11 11:06:56', '2019-06-11 11:06:57'),
(71, 3, 'panel/register/87809692dfb559-a598-4118-9040-a24869327353.jpg', '2019-06-11 11:06:56', '2019-06-11 11:06:57'),
(72, 5, 'panel/register/154246car3.jpg', '2019-06-24 06:32:17', '2019-06-24 06:32:17'),
(73, 5, 'panel/register/8739112016-Hyundai-Sonata-0.jpg', '2019-06-24 06:32:17', '2019-06-24 06:32:17'),
(74, 5, 'panel/register/684943car1.jpg', '2019-06-24 06:32:17', '2019-06-24 06:32:17'),
(75, 5, 'panel/register/660801.jpg', '2019-06-24 06:32:17', '2019-06-24 06:32:17');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `people_id` int(10) UNSIGNED DEFAULT NULL,
  `adv_id` int(10) UNSIGNED DEFAULT NULL,
  `parent_id` mediumint(9) DEFAULT '0',
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `stars` float DEFAULT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci,
  `active` tinyint(4) DEFAULT '0',
  `archive` tinyint(4) DEFAULT '0',
  `like` int(11) DEFAULT '0',
  `unlike` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `people_id`, `adv_id`, `parent_id`, `name`, `email`, `stars`, `text`, `active`, `archive`, `like`, `unlike`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 0, 'علی رضایی', NULL, NULL, 'سلام خیلی خوب بود متکسرک', 0, 0, 0, 0, '2019-06-19 13:04:34', '2019-06-19 13:04:34'),
(2, 2, 2, 0, 'علی رضایی', NULL, NULL, 'شسی شسی شس یشسی شسی شسشس شسی  سشی شسی شس شی شیشسی شسی شی', 0, 0, 0, 0, '2019-06-19 13:15:52', '2019-06-19 13:15:52'),
(3, 2, 2, 0, 'علی رضایی', NULL, NULL, 'sdfsd dsf sdfsdfdsfsdf sdfsd sdflsdflsdflsdflsdlfsdflsdls dlsdfs sdfs ', 0, 0, 0, 0, '2019-06-19 13:18:58', '2019-06-19 13:18:58'),
(4, 2, 1, 0, 'علی رضایی', NULL, NULL, 'پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی پیام تستی ', 0, 0, 0, 0, '2019-06-23 13:58:16', '2019-06-23 13:58:16'),
(5, 2, 1, 4, 'محمد undefined', NULL, NULL, 'sdf sdf sdf sdf  یسبلی بیلبثقل بیبلثق یب یبلثق بیبل ثقب یبلیلثقف ثقفثقثق فثقفثق فثفث فثق', 0, 0, 0, 0, '2019-06-23 15:18:47', '2019-06-23 15:18:47'),
(6, 2, 1, 4, 'محمد سرایی', NULL, NULL, 'cxvxcv  یبل یلی سیب سیبسیبص4س یبسیبص سیب ص سیبصسیب ص صی ص سیصسیب صثق سیسصثق صثق سیبسیب صث س صث سزسیصث بسیزصث صثب صث صثصق صثصقثص ثص ثصقصثقص صصثقصث', 0, 0, 0, 0, '2019-06-23 15:24:47', '2019-06-23 15:24:47'),
(7, 2, 1, 4, 'محمد سرایی', NULL, NULL, 'یسب سیب سیب یسبصثسی بصثق سیبصبیب صبص 4یس', 0, 0, 0, 0, '2019-06-23 15:26:29', '2019-06-23 15:26:29'),
(8, 1, 4, 0, 'محمد سرایی', NULL, NULL, 'یبل بمنلتیبملتنیبل کیبلبیل یبکلمنیبلکثقخح یبگریبل', 0, 0, 0, 0, '2019-06-24 06:42:40', '2019-06-24 06:42:40'),
(9, 1, 4, 8, 'ثقفثقف ثقفثقف', NULL, NULL, 'زبیلیبل ل بلی لیبل یب', 0, 0, 0, 0, '2019-06-24 06:43:39', '2019-06-24 06:43:39');

-- --------------------------------------------------------

--
-- Table structure for table `comment_like_dislike`
--

CREATE TABLE `comment_like_dislike` (
  `id` int(10) NOT NULL,
  `ip` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `user_id` int(10) NOT NULL,
  `comment_id` int(10) NOT NULL,
  `vote` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(10) NOT NULL,
  `title` text COLLATE utf8mb4_persian_ci NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `title`, `active`, `description`, `created_at`, `updated_at`) VALUES
(1, 'werwer', 1, '<p>werw</p>', '2019-06-11 08:27:54', '2019-06-11 08:29:48'),
(2, 'صدای احسان خواجه امیری', 1, '<p>صدای احسان خواجه امیری صدای احسان خواجه امیریصدای احسان خواجه امیری صدای احسان خواجه امیری صدای احسان خواجه امیری صدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه اsdfs sdf sdf sdfsdfمیریصدای احسان خواجه امیریصدای احسان خواجه امیریصدای احسان خواجه امیری</p>', '2019-06-11 08:30:12', '2019-06-11 08:32:13');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(10) UNSIGNED NOT NULL,
  `fType` int(1) NOT NULL DEFAULT '1',
  `cat_id` int(3) NOT NULL,
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(3) NOT NULL,
  `route` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `route`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, '', 'اخبار', 'ثبت، ویرایش و حذف اخبار', '2019-06-09 07:48:44', NULL),
(2, '', 'برندها', 'ثبت و ویرایش برندها', '2019-06-09 07:48:44', NULL),
(3, '', 'خودروها', 'ثبت و ویرایش خودرو ها', '2019-06-09 07:50:55', NULL),
(4, '', 'کسب و کارها', 'ثبت و ویرایش کسب و کارها', '2019-06-09 07:50:55', NULL),
(5, '', 'پرسش های متداول', 'ثبت و ویرایش پرسش های متداول', '2019-06-09 07:53:29', NULL),
(6, '', 'محتوای ثابت سیستم', 'ویرایش متن محتوای ثابت سیستم', '2019-06-09 07:53:29', NULL),
(7, '', 'آگهی های کسب و کار', 'تایید، عدم تایید آگهی های کسب و کارها', '2019-06-09 07:55:49', NULL),
(8, '', 'آگهی های فروش نقدی خودرو', 'تایید و عدم تایید آکهی های فروش نقدی خودرو', '2019-06-09 07:55:49', NULL),
(9, '', 'آگهی های فروش اقساطی خودرو', 'تایید و یا عدم تایید آگهی های فروش اقساطی خودرو', '2019-06-09 07:57:44', NULL),
(10, '', 'کاربران سقف مردم', 'مشاهده لیست کاربران سیستم و مشاهده گزارش عملکرد و لاگ آن ها', '2019-06-09 07:57:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `gr_id` int(10) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `slug` varchar(240) COLLATE utf8mb4_persian_ci NOT NULL,
  `summary` text COLLATE utf8mb4_persian_ci NOT NULL,
  `text` longtext COLLATE utf8mb4_persian_ci NOT NULL,
  `source` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `source_link` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `thumb` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  `visitcnt` int(10) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `gr_id`, `title`, `slug`, `summary`, `text`, `source`, `source_link`, `thumb`, `active`, `visitcnt`, `created_at`, `updated_at`) VALUES
(1, 2, 'سیبسیب', 'سیبسیب', 'سیبیسب', '<p>سیبسی</p>', 'سیبسیب', 'سیبسیب', 'panel/register/913570check1.jpg', 1, 0, '2019-06-09 14:01:08', '2019-06-09 14:01:20'),
(2, 1, 'سیبیسبیس', 'سیبیسبیس', 'سیبسیب', '<p>سیبیسب</p>', 'سیبسیب', 'سیبسی', 'panel/register/311770n00406205-b.jpg', 1, 0, '2019-06-11 07:29:25', '2019-06-11 07:29:32'),
(3, 1, 'صدای احسان خواجه امیری', 'صدای-احسان-خواجه-امیری', 'dsf', '<p>ی</p>', 'پرتال جامع قوه قضائیه جمهوری اسلامی ایران', 'http://www.dadiran.ir/news/articleType/ArticleView/articleId/89533', 'panel/register/676701car1.jpg', 1, 0, '2019-06-11 12:04:03', '2019-06-11 12:04:12');

-- --------------------------------------------------------

--
-- Table structure for table `news_gr`
--

CREATE TABLE `news_gr` (
  `id` int(4) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages_logs`
--

CREATE TABLE `pages_logs` (
  `id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL DEFAULT '0',
  `cat_name` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT '',
  `cat0_id` int(10) NOT NULL,
  `cat0_name` varchar(250) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `the_item_id` int(10) NOT NULL DEFAULT '0',
  `v_date` int(8) NOT NULL,
  `v_cnt` int(10) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) NOT NULL,
  `people_id` int(10) NOT NULL,
  `tracenumber` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `rrn` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `datePaid` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `digitalreceipt` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `issuerbank` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addr` text COLLATE utf8mb4_unicode_ci,
  `pro` int(3) DEFAULT NULL,
  `city` int(3) DEFAULT NULL,
  `telegram` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `business_type` int(10) NOT NULL,
  `business_gr` int(10) NOT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int(10) NOT NULL DEFAULT '0',
  `rcode` int(4) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `credit` int(10) NOT NULL DEFAULT '0',
  `deleteable` int(1) NOT NULL DEFAULT '0',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`id`, `name`, `family`, `slug`, `email`, `username`, `password`, `mobile`, `addr`, `pro`, `city`, `telegram`, `instagram`, `description`, `business_type`, `business_gr`, `phone`, `score`, `rcode`, `status`, `credit`, `deleteable`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'محمد', 'سرایی', '', NULL, NULL, '$2y$10$H718LECC0CWKLK5dXwlKNegDyZlA2jmKaNGr6WxIajSpB7cTbxVam', '09182861717', NULL, NULL, NULL, '@sdfsd', 'sfdgdfdfgdfg', NULL, 0, 0, '091828625664-0395566565', 0, 1880, 0, 0, 0, NULL, '2019-06-02 11:01:37', '2019-06-25 12:07:35'),
(2, 'علی', 'رضایی', '', NULL, NULL, '$2y$10$Mzijj3zsCcXRjwdfNV/8R.At9fwIx..B8FjBM3Wi9lUUe/aGmTffe', '09172861738', NULL, NULL, NULL, '@afdas', 'sdfsdfsdf', NULL, 0, 0, '09182866654654-08947897978', 0, 7794, 0, 0, 0, NULL, '2019-06-19 09:06:12', '2019-06-22 12:25:48'),
(3, 'ثقفثقف', 'ثقفثقف', '', NULL, NULL, '$2y$10$PUgvNOfgC.4TicStdQ66H.EJdkknk1lwRWjlKycW0XfMf5vab.dcK', '09102222222', NULL, NULL, NULL, '@xwer3434534534', 'dfsdfsdf', NULL, 0, 0, '09863215645646-889789797-654654', 0, 2305, 0, 0, 0, NULL, '2019-06-24 06:37:03', '2019-06-24 06:40:12'),
(4, 'علی', 'قربانی', '', NULL, NULL, '$2y$10$rMtJBjJbVksi1HbcLfY34.e5XEIHRUqHM/Id4ggOWiHUfCv3TsCHC', '09182861738', NULL, NULL, NULL, '', '', NULL, 0, 0, '', 0, 3919, 0, 0, 0, NULL, '2019-07-04 11:09:20', '2019-07-08 07:55:28');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(5) NOT NULL,
  `role_id` int(3) NOT NULL,
  `module_id` int(3) NOT NULL,
  `access` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_cities`
--

CREATE TABLE `pro_cities` (
  `id` int(5) NOT NULL,
  `name` varchar(250) COLLATE utf8_persian_ci NOT NULL,
  `pro_id` int(2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `pro_cities`
--

INSERT INTO `pro_cities` (`id`, `name`, `pro_id`, `created_at`, `updated_at`) VALUES
(1, 'آذربايجان شرقي', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(2, 'آذربايجان غربي', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(3, 'اردبيل', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(4, 'اصفهان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(5, 'ايلام', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(6, 'بوشهر', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(7, 'تهران', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(8, 'چهارمحال و بختیاری', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(9, 'خراسان جنوبی', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(10, 'خراسان رضوي', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(11, 'خراسان شمالي', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(12, 'خوزستان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(13, 'زنجان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(14, 'سمنان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(15, 'سيستان و بلوچستان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(16, 'فارس', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(17, 'قزوین', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(18, 'قم', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(19, 'البرز', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(20, 'کرمانشاه', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(21, 'كردستان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(22, 'كرمان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(23, 'كهگيلويه و بويراحمد', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(24, 'گلستان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(25, 'گيلان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(26, 'لرستان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(27, 'مازندران', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(28, 'مركزي', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(29, 'هرمزگان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(30, 'همدان', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(31, 'يزد', 0, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(32, 'آبش‌احمد', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(33, 'آذرشهر', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(34, 'آق‌کند', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(35, 'اسکو', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(36, 'اهر', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(37, 'ایلخچی', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(38, 'باسمنج', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(39, 'بخشایش', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(40, 'بستان‌آباد', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(41, 'بناب', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(42, 'بناب جدید', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(43, 'ترک (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(44, 'ترکمان‌چای', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(45, 'تسوج', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(46, 'تیکمه‌داش', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(47, 'جلفا (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(48, 'خانمرود', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(49, 'خسروشهر', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(50, 'خضرلو', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(51, 'خمارلو', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(52, 'خواجه (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(53, 'دوزدوزان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(54, 'زرنق', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(55, 'زنوز', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(56, 'سراب (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(57, 'سردرود', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(58, 'سهند (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(59, 'سیس', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(60, 'سیه‌رود', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(61, 'شربیان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(62, 'شرفخانه', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(63, 'شندآباد', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(64, 'صوفیان (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(65, 'عجب‌شیر', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(66, 'قره‌آغاج (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(67, 'کشک‌سرای', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(68, 'کلوانق', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(69, 'کوزه‌کنان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(70, 'گوگان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(71, 'لیلان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(72, 'مراغه', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(73, 'مرند', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(74, 'ملکان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(75, 'ملک‌کیان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(76, 'ممقان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(77, 'مهربان (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(78, 'میانه (شهر)', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(79, 'نظرکهریزی', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(80, 'وایقان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(81, 'ورزقان', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(82, 'هادی‌شهر', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(83, 'هریس', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(84, 'هشترود', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(85, 'هوراند', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(86, 'یامچی', 1, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(87, 'آواجیق', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(88, 'ارومیه ', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(89, 'اشنویه', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(90, 'ایواوغلی', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(91, 'باروق', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(92, 'بازرگان', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(93, 'بوکان', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(94, 'پلدشت', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(95, 'پیرانشهر', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(96, 'تازه‌شهر', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(97, 'تکاب', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(98, 'چالدران', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(99, 'چایپاره', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(100, 'چهاربرج', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(101, 'خوی', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(102, 'ربط', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(103, 'سردشت', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(104, 'سرو', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(105, 'سلماس', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(106, 'سیلوانه', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(107, 'سیمینه', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(108, 'سیه‌چشمه', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(109, 'شاهین‌دژ', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(110, 'شوط', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(111, 'فیرورق', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(112, 'قره‌ضیاءالدین', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(113, 'قوشچی', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(114, 'کشاورز', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(115, 'گردکشانه', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(116, 'ماکو', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(117, 'محمدیار ', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(118, 'محمودآباد ', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(119, 'مهاباد', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(120, 'میاندوآب', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(121, 'میرآباد', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(122, 'نالوس', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(123, 'نقده', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(124, 'نوشین‌شهر', 2, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(125, 'آبی‌بیگلو', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(126, 'اردبیل', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(127, 'اصلاندوز', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(128, 'بیله‌سوار', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(129, 'پارس‌آباد', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(130, 'تازه‌کند انگوت', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(131, 'جعفرآباد', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(132, 'خلخال', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(133, 'رضی', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(134, 'سرعین', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(135, 'عنبران', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(136, 'کلور', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(137, 'كوراييم', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(138, 'گرمی', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(139, 'گیوی', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(140, 'لاهرود', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(141, 'مشگین‌شهر', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(142, 'نمین', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(143, 'نیر', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(144, 'هشتجین', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(145, 'هیر', 3, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(146, 'ابریشم  ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(147, 'اردستان ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(148, 'اژیه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(149, 'اصفهان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(150, 'افوس', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(151, 'انارک', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(152, 'ایمان‌شهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(153, 'بادرود', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(154, 'باغ بهادران', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(155, 'برخوار', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(156, 'برف‌انبار', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(157, 'بویین و میاندشت', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(158, 'بهاران‌شهر ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(159, 'بهارستان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(160, 'پیربکران', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(161, 'تودشک', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(162, 'تیران ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(163, 'جندق', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(164, 'جوزدان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(165, 'چادگان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(166, 'چرمهین', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(167, 'چم گردان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(168, 'حبیب‌آباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(169, 'حسن‌آباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(170, 'حنا', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(171, 'خالدآباد ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(172, 'خمینی‌شهر ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(173, 'خوانسار', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(174, 'خور', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(175, 'خور و بیابانک', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(176, 'خوراسگان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(177, 'خورزوق', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(178, 'داران', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(179, 'دامنه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(180, 'درچه‌پیاز', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(181, 'دستگرد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(182, 'دولت‌آباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(183, 'دهاقان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(184, 'دهق', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(185, 'دیزیچه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(186, 'رزوه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(187, 'رضوان‌شهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(188, 'زاینده‌رود', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(189, 'زرین‌شهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(190, 'زواره', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(191, 'زیباشهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(192, 'سده', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(193, 'سگزی', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(194, 'سمیرم', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(195, 'شاهین‌شهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(196, 'شهرضا', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(197, 'طالخونچه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(198, 'عسگران', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(199, 'علویجه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(200, 'فریدن', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(201, 'فریدون‌شهر ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(202, 'فلاورجان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(203, 'فولادشهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(204, 'قهدریجان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(205, 'کرکوند', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(206, 'کرون', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(207, 'کلیشاد و سودرجان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(208, 'کمشجه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(209, 'کمه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(210, 'کوشک ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(211, 'کوهپایه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(212, 'کهریزسنگ', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(213, 'كاشان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(214, 'گز', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(215, 'گلپایگان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(216, 'گل‌دشت', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(217, 'گل‌شهر', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(218, 'گوگد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(219, 'لنجان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(220, 'مبارکه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(221, 'محمدآباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(222, 'مشکات', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(223, 'منظریه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(224, 'مهاباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(225, 'میمه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(226, 'نایین', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(227, 'نجف‌آباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(228, 'نصرآباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(229, 'نطنز', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(230, 'نیک‌آباد', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(231, 'ورزنه', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(232, 'ورنامخواست', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(233, 'وزوان', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(234, 'ونک', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(235, 'هرند', 4, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(236, 'آبدانان', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(237, 'آسمان‌آباد', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(238, 'ارکواز', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(239, 'ایلام', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(240, 'ایوان (شهر)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(241, 'بدره', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(242, 'پهله (ایلام)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(243, 'توحید (شهر)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(244, 'چوار', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(245, 'دره‌شهر', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(246, 'دلگشا', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(247, 'دهلران', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(248, 'زرنه', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(249, 'سراب‌باغ', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(250, 'سرابله', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(251, 'صالح‌آباد (ایلام)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(252, 'لومار', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(253, 'مورموری', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(254, 'موسیان', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(255, 'مهران (شهر)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(256, 'میمه (ایلام)', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(257, 'هلیلان', 5, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(258, 'آب‌پخش', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(259, 'آبدان', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(260, 'امام حسن', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(261, 'اهرم', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(262, 'برازجان', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(263, 'بردخون', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(264, 'بندر ریگ', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(265, 'بندر گناوه', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(266, 'بوشهر', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(267, 'بوشهر', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(268, 'بوشهر', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(269, 'تنگ ارم', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(270, 'تنگستان', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(271, 'جم', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(272, 'چغادک', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(273, 'خارک', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(274, 'خورموج', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(275, 'دالکی', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(276, 'دشتستان', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(277, 'دشتی', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(278, 'دلوار', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(279, 'دیر', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(280, 'دیلم', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(281, 'ریز', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(282, 'سعدآباد', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(283, 'شبانکاره', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(284, 'طاهری', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(285, 'عسلویه', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(286, 'کاکی', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(287, 'کلمه', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(288, 'کنگان', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(289, 'گناوه', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(290, 'نخل تقی', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(291, 'وحدتيه', 6, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(292, 'آبسرد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(293, 'آبعلی', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(294, 'آسار', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(295, 'ارجمند', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(296, 'اسلام‌شهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(297, 'اشتهارد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(298, 'اندیشه', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(299, 'باغستان', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(300, 'باقرشهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(301, 'بومهن ', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(302, 'پاکدشت', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(303, 'پردیس', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(304, 'پیشوا', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(305, 'تجریش ', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(306, 'تهران', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(307, 'جوادآباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(308, 'چهارباغ', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(309, 'چهاردانگه', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(310, 'حسن‌آباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(311, 'دماوند', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(312, 'رباط‌کریم', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(313, 'رودهن', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(314, 'ساوجبلاغ', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(315, 'شاهدشهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(316, 'شریف‌آباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(317, 'شمیرانات', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(318, 'شهر ری', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(319, 'شهریار', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(320, 'صالح‌آباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(321, 'صباشهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(322, 'صفادشت', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(323, 'طالقان', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(324, 'فردوسیه', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(325, 'فشم', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(326, 'فیروزکوه', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(327, 'قدس', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(328, 'قرچک', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(329, 'کرج', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(330, 'کرج ', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(331, 'کمال‌شهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(332, 'کوهسار', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(333, 'کهریزک', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(334, 'کیلان', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(335, 'گرمدره', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(336, 'گلستان', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(337, 'لواسان', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(338, 'ماهدشت', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(339, 'محمدشهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(340, 'مشکین‌دشت', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(341, 'ملارد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(342, 'نسیم‌شهر', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(343, 'نصیرآباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(344, 'نظرآباد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(345, 'وحیدیه', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(346, 'ورامین', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(347, 'ورامین', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(348, 'هشتگرد', 7, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(349, 'آلونی', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(350, 'اردل', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(351, 'اردل', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(352, 'باباحیدر', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(353, 'بروجن', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(354, 'بروجن', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(355, 'بلداجی', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(356, 'بن', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(357, 'جونقان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(358, 'چلگرد', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(359, 'سامان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(360, 'سفیددشت', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(361, 'سودجان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(362, 'سورشجان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(363, 'شلمزار', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(364, 'شهرکرد', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(365, 'شهرکرد', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(366, 'شهرکرد', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(367, 'طاقانک', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(368, 'فارسان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(369, 'فارسان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(370, 'فرادنبه', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(371, 'فرخ‌شهر', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(372, 'کوهرنگ', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(373, 'کیار', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(374, 'کیان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(375, 'گندمان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(376, 'گهرو', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(377, 'لردگان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(378, 'لردگان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(379, 'مال‌خلیفه', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(380, 'ناغان ', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(381, 'نافچ', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(382, 'نقنه', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(383, 'هفشجان', 8, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(384, 'آرین‌شهر', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(385, 'آیسک', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(386, 'اسدیه', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(387, 'اسفدن', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(388, 'اسلامیه', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(389, 'بشرویه', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(390, 'بیرجند', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(391, 'حاجی‌آباد', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(392, 'خضری', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(393, 'خوسف', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(394, 'درمیان', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(395, 'دشت بیاض', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(396, 'زهان', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(397, 'سرایان', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(398, 'سربیشه', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(399, 'سه‌قلعه', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(400, 'شوسف', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(401, 'طبس', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(402, 'فردوس', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(403, 'قائن', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(404, 'قائنات', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(405, 'قهستان', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(406, 'مسينا', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(407, 'مود', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(408, 'نهبندان', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(409, 'نیمبلوک', 9, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(410, 'انابد ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(411, 'باجگیران', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(412, 'باخرز', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(413, 'بایگ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(414, 'بجستان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(415, 'بردسکن', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(416, 'بیدخت', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(417, 'تایباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(418, 'تخت‌جلگه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(419, 'تربت جام', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(420, 'تربت حیدریه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(421, 'جغتای', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(422, 'جوین', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(423, 'چاپشلو', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(424, 'چکنه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(425, 'چناران', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(426, 'خرو ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(427, 'خلیل‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(428, 'خواف', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(429, 'داورزن', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(430, 'دررود', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(431, 'درگز', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(432, 'دولت‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(433, 'رباط سنگ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(434, 'رشتخوار', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(435, 'رضویه ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(436, 'رودآب', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(437, 'ریوش', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(438, 'زاوه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(439, 'سبزوار', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(440, 'سرخس', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(441, 'سلطان‌آباد ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(442, 'سنگان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(443, 'شاندیز', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(444, 'ششتمد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(445, 'شهرآباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(446, 'صالح‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(447, 'طرقبه ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(448, 'عشق‌آباد ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(449, 'فرهادگرد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(450, 'فریمان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(451, 'فیروزه ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(452, 'فیض‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(453, 'قاسم‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(454, 'قدمگاه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(455, 'قلندرآباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(456, 'قوچان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(457, 'کاخک', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(458, 'کاریز', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(459, 'کاشمر', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(460, 'کدکن ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(461, 'کلات ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(462, 'کندر ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(463, 'گناباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(464, 'لطف‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(465, 'مشهد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(466, 'مشهد ریزه', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(467, 'ملک‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(468, 'مه‌ولات', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(469, 'نشتیفان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(470, 'نصرآباد ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(471, 'نقاب', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(472, 'نوخندان', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(473, 'نیل‌شهر ', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(474, 'همت‌آباد', 10, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(475, 'آشخانه', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(476, 'اسفراین', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(477, 'اسفراین', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(478, 'بجنورد', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(479, 'پیش‌قلعه', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(480, 'جاجرم', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(481, 'حصار', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(482, 'درق', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(483, 'راز ', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(484, 'سنخواست', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(485, 'شوقان', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(486, 'شیروان', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(487, 'صفی‌آباد ', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(488, 'فاروج', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(489, 'قاضی', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(490, 'گرم‌خان', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(491, 'گرمه', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(492, 'لوجلی', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(493, 'مانه و سملقان', 11, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(494, 'آبادان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(495, 'آغاجاری', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(496, 'اروندکنار', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(497, 'الوان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(498, 'امیدیه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(499, 'اندیکا', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(500, 'اندیمشک', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(501, 'اهواز', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(502, 'ایذه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(503, 'باغ‌ملک ', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(504, 'بستان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(505, 'بندر چمران', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(506, 'بندرامام خمینی ', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(507, 'بهبهان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(508, 'جایزان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(509, 'حر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(510, 'حسینیه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(511, 'حمیدیه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(512, 'خرمشهر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(513, 'خرمشهر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(514, 'دزآب', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(515, 'دزفول', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(516, 'دشت آزادگان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(517, 'دهدز', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(518, 'رامشیر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(519, 'رامهرمز', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(520, 'رفیع ', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(521, 'ریاحی', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(522, 'زهره', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(523, 'سالند', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(524, 'سردشت', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(525, 'سوسنگرد', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(526, 'شادگان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(527, 'شوش', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(528, 'شوشتر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(529, 'شیبان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(530, 'صفی‌آباد', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(531, 'صیدون', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(532, 'قلعه خواجه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(533, 'قلعه‌تل', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(534, 'گتوند', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(535, 'لالی ', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(536, 'ماهشهر ', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(537, 'مسجدسلیمان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(538, 'مقاومت', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(539, 'ملاثانی', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(540, 'میانرود', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(541, 'مینوشهر', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(542, 'ویس', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(543, 'هفتگل', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(544, 'هندیجان', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(545, 'هویزه', 12, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(546, 'آب‌بر', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(547, 'ابهر ', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(548, 'ارمغان‌خانه', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(549, 'ایجرود', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(550, 'چورزق', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(551, 'حلب', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(552, 'خدابنده', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(553, 'خرمدره', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(554, 'دندی', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(555, 'زرین‌آباد', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(556, 'زرین‌رود', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(557, 'زنجان', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(558, 'سجاس', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(559, 'سلطانیه', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(560, 'سهرورد', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(561, 'صائین‌قلعه', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(562, 'طارم', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(563, 'قیدار', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(564, 'گرماب', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(565, 'ماه‌نشان', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(566, 'هیدج', 13, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(567, 'آرادان', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(568, 'امیریه ', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(569, 'ایوانکی', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(570, 'بسطام', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(571, 'بیارجمند ', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(572, 'دامغان', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(573, 'درجزین ', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(574, 'دیباج', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(575, 'سرخه', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(576, 'سمنان', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(577, 'شاهرود', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(578, 'شهمیرزاد', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(579, 'کلاته خیج ', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(580, 'گرمسار', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(581, 'مجن', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(582, 'مهدی‌شهر', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(583, 'میامی', 14, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(584, 'ادیمی', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(585, 'اسپکه', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(586, 'ایرانشهر', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(587, 'بزمان', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(588, 'بمپور', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(589, 'بنت', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(590, 'بنجار', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(591, 'پیشین', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(592, 'جالق', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(593, 'چابهار', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(594, 'خاش', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(595, 'دلگان', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(596, 'دوست‌محمد', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(597, 'راسک', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(598, 'زابل', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(599, 'زابلی', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(600, 'زاهدان', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(601, 'زهک', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(602, 'سراوان', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(603, 'سرباز', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(604, 'سوران', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(605, 'سیب و سوران', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(606, 'سیرکان', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(607, 'فنوج', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(608, 'قصرقند', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(609, 'کنارک', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(610, 'گلمورتی', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(611, 'محمد‌آباد', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(612, 'میرجاوه', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(613, 'نصرت‌آباد', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(614, 'نگور', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(615, 'نوک‌آباد', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(616, 'نیک‌شهر', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(617, 'هیرمند', 15, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(618, 'آباده ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(619, 'آباده طشک', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(620, 'اردکان ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(621, 'ارسنجان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(622, 'استهبان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(623, 'اسیر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(624, 'اشکنان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(625, 'افزر ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(626, 'اقلید', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(627, 'اوز', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(628, 'اهل ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(629, 'ایج', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(630, 'ایزدخواست', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(631, 'باب‌انار', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(632, 'بالاده', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(633, 'بنارویه', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(634, 'بوانات', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(635, 'بهمن', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(636, 'بیرم', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(637, 'بیضا', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(638, 'پاسارگاد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(639, 'جنت‌شهر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(640, 'جویم', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(641, 'جهرم', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(642, 'حاجی‌آباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(643, 'خاوران', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(644, 'خرامه', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(645, 'خرم‌بید', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(646, 'خشت', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(647, 'خنج', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(648, 'خور', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(649, 'داراب', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(650, 'داریان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(651, 'دهرم', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(652, 'رامجرد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(653, 'رستم ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(654, 'رونیز', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(655, 'زاهدشهر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(656, 'زرقان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(657, 'زرین‌دشت', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(658, 'سپیدان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(659, 'سده', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(660, 'سروستان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(661, 'سعادت‌شهر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(662, 'سورمق', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(663, 'سوریان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(664, 'سیدان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(665, 'ششده', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(666, 'شهر پیر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(667, 'شیراز', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(668, 'صغاد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(669, 'صفاشهر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(670, 'علا', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(671, 'فتح‌آباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(672, 'فراشبند', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(673, 'فسا', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(674, 'فیروزآباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(675, 'قائمیه', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(676, 'قادرآباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(677, 'قطب‌آباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(678, 'قیر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(679, 'کارزین', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(680, 'کازرون ', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(681, 'کامفیروز', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(682, 'کره‌ای', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(683, 'کنارتخته', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(684, 'کوار', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(685, 'گراش', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(686, 'گله‌دار', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(687, 'لار', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(688, 'لارستان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(689, 'لامرد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(690, 'لپویی', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(691, 'لطیفی', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(692, 'مرودشت', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(693, 'مشکان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(694, 'مصیری', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(695, 'ممسنی', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(696, 'مهر', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(697, 'میمند', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(698, 'نوجین', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(699, 'نودان', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(700, 'نورآباد', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(701, 'نی‌ریز', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(702, 'وراوی', 16, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(703, 'آبگرم', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(704, 'آبیک', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(705, 'آوج', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(706, 'ارداق', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(707, 'اسفرورین', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(708, 'اقبالیه', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(709, 'البرز ', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(710, 'الوند', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(711, 'بویین‌زهرا', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(712, 'بیدستان', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(713, 'تاکستان', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(714, 'خاکعلی', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(715, 'خرمدشت', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(716, 'دانسفهان', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(717, 'رازمیان', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(718, 'سگزآباد', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(719, 'سیردان', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(720, 'شال', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(721, 'ضیاءآباد', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(722, 'قزوین', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(723, 'کوهین', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(724, 'محمدیه', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(725, 'محمودآباد', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(726, 'معلم‌کلایه', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(727, 'نرجه', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(728, 'نمونه ', 17, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(729, 'جعفریه ', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(730, 'دستجرد', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(731, 'سلفچگان', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(732, 'قم', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(733, 'قنوات', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(734, 'کهک', 18, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(735, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(736, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(737, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(738, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(739, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(740, '', 19, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(741, 'ازگله ', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(742, 'اسلام‌آباد غرب ', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(743, 'باباجانی', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(744, 'باینگان', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(745, 'بیستون', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(746, 'پاوه', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(747, 'تازه‌آباد', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(748, 'ثلاث ', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(749, 'جوانرود', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(750, 'حمیل ', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(751, 'دالاهو', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(752, 'رباط', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(753, 'روانسر', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(754, 'سرپل ذهاب', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(755, 'سرمست', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(756, 'سطر', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(757, 'سنقر', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(758, 'سومار', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(759, 'صحنه', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(760, 'قصر شیرین', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(761, 'کرمانشاه', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(762, 'کرند غرب', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(763, 'کنگاور', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(764, 'کوزران', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(765, 'گهواره', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(766, 'گیلان غرب', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(767, 'میان‌راهان', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(768, 'نودشه', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(769, 'نوسود', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(770, 'هرسین', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(771, 'هلشی', 20, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(772, 'آرمرده ', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(773, 'بابارشانی', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18');
INSERT INTO `pro_cities` (`id`, `name`, `pro_id`, `created_at`, `updated_at`) VALUES
(774, 'بانه', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(775, 'بلبان‌آباد', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(776, 'بویین سفلی', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(777, 'بیجار', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(778, 'چناره', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(779, 'دزج', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(780, 'دلبران', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(781, 'دهگلان', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(782, 'دیواندره', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(783, 'زرینه', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(784, 'سروآباد', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(785, 'سریش‌آباد', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(786, 'سقز', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(787, 'سنندج', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(788, 'شویشه', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(789, 'صاحب', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(790, 'قروه', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(791, 'کامیاران', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(792, 'کانی‌دینار', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(793, 'کانی‌سور ', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(794, 'مریوان', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(795, 'موچش', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(796, 'یاسوکند', 21, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(797, 'اختیارآباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(798, 'ارزوئیه', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(799, 'امین‌شهر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(800, 'انار', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(801, 'اندوهجرد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(802, 'باغین', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(803, 'بافت', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(804, 'بردسیر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(805, 'بروات', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(806, 'بزنجان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(807, 'بم', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(808, 'بهرمان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(809, 'پاریز', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(810, 'جبالبارز', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(811, 'جوپار ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(812, 'جوزم ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(813, 'جیرفت', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(814, 'چترود', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(815, 'خاتون‌آباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(816, 'خانوک', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(817, 'خرسند', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(818, 'درب بهشت', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(819, 'دهج', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(820, 'رابر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(821, 'راور', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(822, 'راین', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(823, 'رفسنجان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(824, 'رودبار جنوب', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(825, 'ریحان‌شهر ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(826, 'زرند', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(827, 'زنگی‌آباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(828, 'زیدآباد ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(829, 'سیرجان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(830, 'شهداد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(831, 'شهر بابک', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(832, 'صفائیه', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(833, 'عنبرآباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(834, 'فاریاب', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(835, 'فهرج ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(836, 'قلعه گنج', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(837, 'کاظم‌آباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(838, 'کرمان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(839, 'کشکوئیه', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(840, 'کوهبنان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(841, 'کهنوج', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(842, 'کیان‌شهر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(843, 'گلباف', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(844, 'گلزار', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(845, 'ماهان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(846, 'محمدآباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(847, 'محی‌آباد', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(848, 'مردهک', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(849, 'مس سرچشمه', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(850, 'منوجان', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(851, 'نجف‌شهر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(852, 'نرماشیر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(853, 'نظام‌شهر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(854, 'نگار', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(855, 'نودژ', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(856, 'هجدک', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(857, 'یزدان‌شهر', 22, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(858, 'باشت', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(859, 'بویراحمد', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(860, 'بهمئی', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(861, 'پاتاوه', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(862, 'چرام', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(863, 'چیتاب', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(864, 'دنا ', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(865, 'دوگنبدان', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(866, 'دهدشت', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(867, 'دیشموک', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(868, 'سوق', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(869, 'سی‌سخت', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(870, 'قلعه رئیسی', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(871, 'کهگیلویه', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(872, 'گچساران', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(873, 'گراب سفلی', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(874, 'لنده', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(875, 'لیکک', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(876, 'مارگون', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(877, 'یاسوج ', 23, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(878, 'آزادشهر', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(879, 'آق‌قلا', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(880, 'انبار آلوم ', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(881, 'اینچه‌برون', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(882, 'بندر ترکمن', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(883, 'بندر گز', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(884, 'خان‌ببین', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(885, 'دلند', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(886, 'رامیان ', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(887, 'سرخنکلاته', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(888, 'سیمین‌شهر ', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(889, 'علی‌آباد', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(890, 'فاضل‌آباد', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(891, 'کردکوی', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(892, 'کلاله', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(893, 'گالیکش', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(894, 'گرگان', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(895, 'گمیشان', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(896, 'گنبد کاووس', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(897, 'مراوه‌تپه', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(898, 'مینودشت', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(899, 'نگین‌شهر ', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(900, 'نوده خاندوز ', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(901, 'نوکنده', 24, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(902, 'آستارا', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(903, 'آستانه اشرفیه', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(904, 'احمدسرگوراب', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(905, 'اسالم', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(906, 'اطاقور', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(907, 'املش', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(908, 'بازارجمعه', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(909, 'بره‌سر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(910, 'بندر انزلی', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(911, 'پره‌سر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(912, 'توتکابن ', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(913, 'جیرنده', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(914, 'چابکسر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(915, 'چاف و چمخاله', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(916, 'چوبر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(917, 'حویق', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(918, 'خشکبیجار', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(919, 'خمام', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(920, 'دیلمان', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(921, 'رانکوه', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(922, 'رحیم‌آباد', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(923, 'رستم‌آباد', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(924, 'رشت', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(925, 'رضوان‌شهر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(926, 'رودبار', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(927, 'رودبنه', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(928, 'رودسر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(929, 'سنگر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(930, 'سیاهکل', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(931, 'شفت', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(932, 'شلمان', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(933, 'صومعه‌سرا', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(934, 'فومن', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(935, 'کلاچای', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(936, 'کوچصفهان ', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(937, 'کومله ', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(938, 'کیاشهر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(939, 'گوراب زرمیخ', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(940, 'لاهیجان', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(941, 'لشت نشا ', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(942, 'لنگرود', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(943, 'لوشان', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(944, 'لوندویل', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(945, 'لیسار', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(946, 'ماسال', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(947, 'ماسوله', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(948, 'مرجغل', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(949, 'منجیل', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(950, 'واجارگاه', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(951, 'هشتپر', 25, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(952, 'ازنا', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(953, 'اشترینان', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(954, 'الشتر', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(955, 'الیگودرز', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(956, 'بروجرد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(957, 'پل‌دختر', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(958, 'چالانچولان', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(959, 'چغلوندی', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(960, 'چقابل', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(961, 'خرم‌آباد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(962, 'درب گنبد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(963, 'دلفان', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(964, 'دورود', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(965, 'زاغه', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(966, 'سپیددشت', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(967, 'سراب‌دوره', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(968, 'سلسله', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(969, 'فیروزآباد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(970, 'کونانی', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(971, 'کوهدشت', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(972, 'گراب', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(973, 'معمولان', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(974, 'مومن‌آباد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(975, 'مویسیان', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(976, 'نورآباد', 26, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(977, 'آلاشت', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(978, 'آمل', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(979, 'امیرشهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(980, 'ایزدشهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(981, 'بابل', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(982, 'بابلسر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(983, 'بلده', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(984, 'بهشهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(985, 'بهنمیر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(986, 'پل سفید', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(987, 'تنکابن', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(988, 'جویبار', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(989, 'چالوس', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(990, 'چمستان', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(991, 'خرم‌آباد', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(992, 'خلیل‌شهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(993, 'خوش‌رودپی', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(994, 'دابودشت', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(995, 'رامسر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(996, 'رستمکلا ', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(997, 'رویان', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(998, 'رینه', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(999, 'زرگرمحله', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1000, 'زیرآب', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1001, 'ساری', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1002, 'سرخ‌رود', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1003, 'سلمان‌شهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1004, 'سوادکوه', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1005, 'سورک', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1006, 'شیرگاه', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1007, 'شیرود', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1008, 'عباس‌آباد', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1009, 'فریدون‌کنار', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1010, 'فریم', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1011, 'قائم‌شهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1012, 'کتالم و سادات‌شهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1013, 'کلارآباد', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1014, 'کلاردشت', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1015, 'کله‌بست', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1016, 'کوهی‌خیل', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1017, 'کیاسر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1018, 'کیاکلا', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1019, 'گتاب', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1020, 'گزنک', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1021, 'گلوگاه', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1022, 'گلوگاه بابل', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1023, 'محمودآباد', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1024, 'مرزن‌آباد', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1025, 'مرزیکلا', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1026, 'نشتارود', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1027, 'نکا', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1028, 'نور', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1029, 'نوشهر', 27, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1030, 'آستانه', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1031, 'آشتیان', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1032, 'اراک', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1033, 'پرندک', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1034, 'تفرش', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1035, 'توره', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1036, 'خمین', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1037, 'خنداب', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1038, 'خنداب', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1039, 'داودآباد', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1040, 'دلیجان', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1041, 'رازقان ', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1042, 'زاویه', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1043, 'زرندیه', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1044, 'ساوه', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1045, 'سنجان', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1046, 'شازند', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1047, 'شازند', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1048, 'غرق‌آباد', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1049, 'فرمهین', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1050, 'قورچی‌باشی', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1051, 'کرهرود', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1052, 'کمیجان', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1053, 'مأمونیه', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1054, 'محلات', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1055, 'میلاجرد', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1056, 'نراق', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1057, 'نوبران', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1058, 'نیم‌ور', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1059, 'هندودر', 28, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1060, 'ابوموسی', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1061, 'بستک', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1062, 'بندر چارک', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1063, 'بندر خمیر', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1064, 'بندر عباس', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1065, 'بندرلنگه', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1066, 'پارسیان', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1067, 'جاسک', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1068, 'جناح ', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1069, 'حاجی‌آباد', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1070, 'درگهان', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1071, 'دهبارز', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1072, 'رودان ', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1073, 'رویدر', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1074, 'زیارت‌علی', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1075, 'سندرک', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1076, 'سوزا', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1077, 'سیریک ', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1078, 'فارغان', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1079, 'فین', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1080, 'قشم', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1081, 'کنگ', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1082, 'کیش', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1083, 'میناب', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1084, 'هرمز', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1085, 'هشت‌بندی', 29, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1086, 'ازندریان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1087, 'اسدآباد', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1088, 'برزول', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1089, 'بهار', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1090, 'تویسرکان ', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1091, 'جورقان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1092, 'جوکار', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1093, 'درجزین', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1094, 'دمق', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1095, 'رزن', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1096, 'زنگنه', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1097, 'سامن', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1098, 'سرکان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1099, 'شیرین‌سو', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1100, 'صالح‌آباد', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1101, 'فامنین', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1102, 'فرسفج', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1103, 'فیروزان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1104, 'قروه', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1105, 'قهاوند', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1106, 'کبودرآهنگ', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1107, 'گل‌تپه', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1108, 'گیان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1109, 'لالجین', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1110, 'مریانج', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1111, 'ملایر', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1112, 'مهاجران', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1113, 'نهاوند', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1114, 'همدان', 30, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1115, 'ابرکوه', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1116, 'احمدآباد', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1117, 'اردکان', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1118, 'اشکذر', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1119, 'بافق', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1120, 'بهاباد', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1121, 'تفت', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1122, 'حمیدیا', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1123, 'خاتم', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1124, 'خضرآباد', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1125, 'دیهوک', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1126, 'زارچ', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1127, 'شاهدیه', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1128, 'صدوق', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1129, 'طبس', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1130, 'عشق‌آباد', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1131, 'عقدا', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1132, 'مروست', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1133, 'مهردشت', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1134, 'مهریز', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1135, 'میبد ', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1136, 'ندوشن', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1137, 'نیر ', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1138, 'هرات', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18'),
(1139, 'یزد', 31, '2019-01-22 11:01:18', '2019-01-22 11:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(3) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `static_content`
--

CREATE TABLE `static_content` (
  `id` int(2) NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `static_content`
--

INSERT INTO `static_content` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 'درباره ما', '<p>متن درباره ما</p>', '2019-06-10 08:33:03', '2019-06-11 08:57:48'),
(2, 'تماس با ما', '<p>متن تماس با ما</p>', '2019-06-10 08:33:03', '2019-06-11 08:53:46'),
(3, 'شرایط فروش اقساطی', '                                              <p>1- عدم چک برگشتی و یا اقساط معوقه خریدار و ضامن\r\n                                                </p><p>2- چک صیادی خریدار و ضامن از بانک\r\n                                            </p><p>3- کپی شناسنامه و کارت ملی خریدار و ضامن\r\n                                            </p><p>4- چک کارمندی ضامن یا خریدار( در صورتی که خریدار چک کارمندی داشته باشد، چک ضامن لازم نیست )\r\n                                            </p><p>5- ارائه کد سقف مردم از سامانه سقف مردم\r\n\r\n                                            </p>', '2019-06-10 08:33:03', '2019-06-11 08:33:16'),
(4, 'متن پیام دعوت دوستان', '', '2019-06-19 07:27:36', NULL),
(5, 'متن راهنمای جدول اقساط', '', '2019-06-19 07:27:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlogs`
--

CREATE TABLE `userlogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` int(4) NOT NULL,
  `row_id` int(11) NOT NULL,
  `str` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(3) DEFAULT '0',
  `user_id` int(10) NOT NULL DEFAULT '0',
  `secret` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aType` int(1) NOT NULL DEFAULT '0',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addr` text COLLATE utf8mb4_unicode_ci,
  `pro` int(3) DEFAULT NULL,
  `city` int(3) DEFAULT NULL,
  `telegram` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` int(10) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `deleteable` int(1) NOT NULL DEFAULT '0',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `user_id`, `secret`, `aType`, `name`, `family`, `slug`, `email`, `username`, `password`, `mobile`, `addr`, `pro`, `city`, `telegram`, `instagram`, `phone`, `score`, `status`, `deleteable`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 0, 0, 'KNJCYNBJLARSITZY', 1, 'مدیر', 'سیستم', '', 'sarayi.cactux@gmail.com', 'admin', '$2y$10$H718LECC0CWKLK5dXwlKNegDyZlA2jmKaNGr6WxIajSpB7cTbxVam', NULL, NULL, NULL, NULL, '@sddf', 'instagram', '091828655-265646889-08623465456', 0, 0, 1, '2019-02-04 09:32:42', '2019-01-29 08:30:36', '2019-06-11 14:34:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advs`
--
ALTER TABLE `advs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adv_image`
--
ALTER TABLE `adv_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_gr`
--
ALTER TABLE `business_gr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `business_type`
--
ALTER TABLE `business_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_advs`
--
ALTER TABLE `car_advs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_adv_image`
--
ALTER TABLE `car_adv_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_images`
--
ALTER TABLE `car_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_reviews_user_id_index` (`people_id`),
  ADD KEY `tbl_reviews_article_id_index` (`adv_id`);

--
-- Indexes for table `comment_like_dislike`
--
ALTER TABLE `comment_like_dislike`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_gr`
--
ALTER TABLE `news_gr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages_logs`
--
ALTER TABLE `pages_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_date` (`v_date`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `people_email_unique` (`email`),
  ADD UNIQUE KEY `people_username_unique` (`username`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_cities`
--
ALTER TABLE `pro_cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `static_content`
--
ALTER TABLE `static_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlogs`
--
ALTER TABLE `userlogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userlogs_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advs`
--
ALTER TABLE `advs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `adv_image`
--
ALTER TABLE `adv_image`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `business_gr`
--
ALTER TABLE `business_gr`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `business_type`
--
ALTER TABLE `business_type`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `car_advs`
--
ALTER TABLE `car_advs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `car_adv_image`
--
ALTER TABLE `car_adv_image`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `car_images`
--
ALTER TABLE `car_images`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `comment_like_dislike`
--
ALTER TABLE `comment_like_dislike`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `news_gr`
--
ALTER TABLE `news_gr`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_logs`
--
ALTER TABLE `pages_logs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pro_cities`
--
ALTER TABLE `pro_cities`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1140;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `static_content`
--
ALTER TABLE `static_content`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `userlogs`
--
ALTER TABLE `userlogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `userlogs`
--
ALTER TABLE `userlogs`
  ADD CONSTRAINT `userlogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
